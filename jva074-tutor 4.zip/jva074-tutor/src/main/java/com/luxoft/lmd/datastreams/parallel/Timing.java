package com.luxoft.lmd.datastreams.parallel;

import com.google.common.base.Stopwatch;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.time.Duration;
import java.util.concurrent.Callable;
import java.util.stream.IntStream;

public class Timing {
	private final static Logger logger = LoggerFactory.getLogger(Timing.class);

	private Timing() {
	}

	public static <V> TimedResult<V> runTimed(String jobName, Callable<V> task) {
		try (var ignored = MDC.putCloseable("instance", jobName)) {
			var watch = Stopwatch.createStarted();
			V result = null;
			try {
				result = task.call();
			} catch (Exception e) {
				ExceptionUtils.rethrow(e);
			}
			watch.stop();
			Duration elapsed = watch.elapsed();
			if (jobName != null)
				logger.trace("elapsed {} ms, result: {}", elapsed.toMillis(), result);
			return new TimedResult<>(result, elapsed);
		}
	}

	public static <V> void benchmark(String taskNamePrefix, int count, Callable<V> task) {
		// warmup
		runTimed(null, task);

		try (var closeable = MDC.putCloseable("task", taskNamePrefix)) {
			double averageRunningTime =
				IntStream.range(0, count)
					.mapToObj(index -> taskNamePrefix + "[" + index + "]")
					.map(taskName -> runTimed(taskName, task))
					.mapToLong(value -> value.duration().toNanos())
					.average().orElseThrow();

			Benchmark.logger.info("avg: {}ns, {}ms", Math.round(averageRunningTime), Math.round(averageRunningTime / 10000) / 100.0);
		}
	}
}
