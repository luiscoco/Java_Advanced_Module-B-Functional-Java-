package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class Finders {
	private static Stream<Integer> buildSimpleStream() {
		return Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9);
	}

	@Test
	public void findFirst() {
		Optional<Integer> first =
			buildSimpleStream()
				.findFirst();

		assertAll(
			() -> assertTrue(first.isPresent()),
			() -> assertEquals(1, first.get())
		);
	}

	@Test
	public void findFirstOnEmptyStream() {
		Optional<String> first =
			Stream.<String>empty()
				.findFirst();

		assertAll(
			() -> assertTrue(first.isEmpty())
		);
	}
}
