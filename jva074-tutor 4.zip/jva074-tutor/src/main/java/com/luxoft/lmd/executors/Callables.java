package com.luxoft.lmd.executors;

import org.apache.commons.lang3.time.StopWatch;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/*
 * Interface Callable <T> allows to create threads that return the execution result T.
 * 1) Try to run the class and look at the results and execution time.
 * Replace the call of newSingleThreadExecutor () to newFixedThreadPool() and compare the execution time.
 * 2) Instead of executorService.execute() use executorService.submit().
 * Save results in the array of Future objects.
 * 3) Try to stop the execution of the first 5 streams using the method cancel().
 * Handle CancellationException.
 * 4) Before finishing the thread add sleep for 15 milliseconds.
 * Experiment with the size of the pool: how many threads will complete the work, and how many do not (set, for example, pool of 2).
 * On termination of the thread, add logging, informing if the work was finished:
 * log ("canceling thread" + i + ", isDone =" + results.get(i).isDone());
 * 5) Add a message after the completion of sleep of StringGenerator:
 * log ("thread is finished:" + allStrings [index]);
 * Try to experiment with the parameter of cancel() method: set true or false.
 */

public class Callables {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Test
	public void testCallable() {

//		ExecutorService executorService = Executors.newSingleThreadExecutor();
		ExecutorService executorService = Executors.newFixedThreadPool(2);
//		ExecutorService executorService = Executors.newCachedThreadPool();

		logger.info("app start");
		StopWatch watch = StopWatch.createStarted();

		List<Future<String>> results =
			IntStream.range(0, 10)
				.mapToObj((index) -> executorService.submit(new StringGenerator()))
				.toList();

		String resultStr =
			results
				.stream()
				.map(f -> {
					try {
						return f.get();
					} catch (InterruptedException | ExecutionException e) {
						throw new RuntimeException(e);
					}
				})
				.collect(Collectors.joining(" "));

		watch.split();
		long finish = System.nanoTime();
		logger.info("tasks were running: {}", watch.formatSplitTime());

		logger.info("combined result: {}", resultStr);

		executorService.shutdown();
		try {
			executorService.awaitTermination(1000, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		executorService.shutdownNow();
		watch.stop();

		logger.info("the app was running: {}", watch.formatTime());
	}
}
