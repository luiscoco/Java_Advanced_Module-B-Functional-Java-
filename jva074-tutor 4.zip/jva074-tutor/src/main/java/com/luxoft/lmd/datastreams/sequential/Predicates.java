package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class Predicates {
	@Test
	public void twoFilters() {
		List<Integer> result
			= Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.filter(v -> v > 3)
			.filter(v -> v < 8)
			.toList();

		assertEquals(
			List.of(4, 5, 6, 7),
			result
		);
	}

	@Test
	public void singleFiltersLogicalExpression() {
		List<Integer> result
			= Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.filter(v -> v < 3 || v > 8)
			.toList();

		assertEquals(
			List.of(1, 2, 9),
			result
		);
	}

	@Test
	public void singleFiltersPredicateComposition() {
		Predicate<Integer> firstP = value -> value < 3;
		Predicate<Integer> secondP = value -> value > 8;

		List<Integer> result
			= Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.filter(firstP.or(secondP))
			.toList();

		assertEquals(
			List.of(1, 2, 9),
			result
		);
	}

	@Test
	public void negation() {
		Optional<Integer> noFour
			= Stream.of(1, 2, 3, 4, 5, 6, 4, 7, 8, 9)
			.filter(Predicate.isEqual(4).negate())
			.findFirst();


		assertAll(
			() -> assertTrue(noFour.isPresent()),
			() -> assertEquals(1, noFour.get())
		);
	}
}
