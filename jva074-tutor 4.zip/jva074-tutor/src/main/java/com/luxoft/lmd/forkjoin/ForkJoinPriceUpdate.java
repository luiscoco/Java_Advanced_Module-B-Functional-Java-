package com.luxoft.lmd.forkjoin;

import net.datafaker.Faker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

public class ForkJoinPriceUpdate {
	private final static Logger LOGGER = LoggerFactory.getLogger(ForkJoinPriceUpdate.class);
	private static Faker faker = new Faker();

	public static void main(String[] args) {
		List<Product> products = generateTestData(100000);

		ForkJoinPool pool = new ForkJoinPool();
		LOGGER.info("Parallelism: {}", pool.getParallelism());
		PriceUpdateTask task =
			new PriceUpdateTask(products, 0, products.size(), 0.2);

		pool.execute(task);
		do {
			LOGGER.info("Thread Count: {}", pool.getActiveThreadCount());
			LOGGER.info("Thread Steal: {}", pool.getStealCount());
			LOGGER.info("Parallelism: {}", pool.getParallelism());
			LOGGER.info("---");
			try {
				TimeUnit.MILLISECONDS.sleep(1);
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			}
		} while (!task.isDone());

		pool.shutdown();

		LOGGER.info("product[1]={}", products.get(1));
	}

	private static List<Product> generateTestData(int length) {
		return faker.collection(
				() -> new Product(faker.commerce().productName(), faker.random().nextDouble(7.0, 99.0))
			).len(length)
			.generate();
	}
}
