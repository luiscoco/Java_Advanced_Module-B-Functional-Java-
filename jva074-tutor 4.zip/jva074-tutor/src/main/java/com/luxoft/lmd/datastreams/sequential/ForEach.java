package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.Test;

import java.util.function.Consumer;
import java.util.stream.Stream;

public class ForEach {
	@Test
	public void forEachLambda() {
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.forEach(value -> System.out.println(value));
	}

	@Test
	public void forEachMethodRef() {
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.forEach(System.out::println);
	}

	@Test
	public void forEachChainedConsumer() {
		Consumer<Integer> consumer1 = s -> System.out.println("first consumer " + s);
		Consumer<Integer> consumer2 = s -> System.out.println("second consumer " + s);
		Consumer<Integer> composite = consumer1.andThen(consumer2);
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.forEach(composite);
	}
}
