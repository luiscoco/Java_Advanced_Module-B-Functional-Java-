package com.luxoft.lmd.executors;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.*;
import java.util.stream.IntStream;

public class CustomExecutors {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Test
	public void fixedThreadPool() {
		ThreadPoolExecutor executor =
			new ThreadPoolExecutor(
				4, 4,
				0, TimeUnit.MILLISECONDS,
				new LinkedBlockingQueue<Runnable>());

		try (ExecutorService executorService = executor) {
			executorService.execute(() -> logger.info("this is exactly like Executors.newFixedThreadPoolExecutor"));
		}
	}

	@Test
	public void likeCachedThreadPool() {
		ThreadPoolExecutor executor =
			new ThreadPoolExecutor(
				10, Runtime.getRuntime().availableProcessors() * 12,
				60, TimeUnit.SECONDS,
				new LinkedBlockingQueue<Runnable>());

		try (ExecutorService executorService = executor) {
			executorService.execute(() -> logger.info("this one is like a cached thread pool but bounded!"));
		}
	}

	@Test
	public void customExecutorWithDiscardPolicy() {
		ThreadPoolExecutor executor =
			new ThreadPoolExecutor(
				4, 4,
				60, TimeUnit.SECONDS,
				new LinkedBlockingQueue<Runnable>(10));
		executor.setRejectedExecutionHandler(new ThreadPoolExecutor.DiscardPolicy());

		try (ExecutorService executorService = executor) {
			IntStream.range(0, 100)
				.forEach(index -> executorService.execute(() -> logger.info("running task: " + index)));
		}
	}

	@Test
	public void customExecutorWithDiscardOldestPolicy() {
		ThreadPoolExecutor executor =
			new ThreadPoolExecutor(
				4, 4,
				60, TimeUnit.SECONDS,
				new LinkedBlockingQueue<Runnable>(10));
		executor.setRejectedExecutionHandler(new ThreadPoolExecutor.DiscardOldestPolicy());

		try (ExecutorService executorService = executor) {
			IntStream.range(0, 100)
				.forEach(index -> executorService.execute(() -> logger.info("running task: " + index)));
		}
	}

	@Test
	public void customExecutorWithCallerRunsPolicy() {
		ThreadPoolExecutor executor =
			new ThreadPoolExecutor(
				4, 4,
				60, TimeUnit.SECONDS,
				new LinkedBlockingQueue<Runnable>(10));
		executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());

		try (ExecutorService executorService = executor) {
			IntStream.rangeClosed(1, 100)
				.forEach(index -> executorService.execute(() -> logger.info("running task: " + index)));
		}
	}

	@Test
	public void customExecutorWithRejectPolicy() {
		ThreadPoolExecutor executor =
			new ThreadPoolExecutor(
				4, 4,
				60, TimeUnit.SECONDS,
				new LinkedBlockingQueue<Runnable>(10));
		executor.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());

		try (ExecutorService executorService = executor) {
			IntStream.rangeClosed(1, 100)
				.forEach(index -> {
						try {
							executorService.execute(() -> logger.info("running task: " + index));
						} catch (RejectedExecutionException e) {
							logger.error("task {} got rejected", index, e);
						}
					}
				);
		}
	}
}
