package com.luxoft.lmd;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Stream;

public class TrickyCode {
	@Test @Order(1)
	public void peekNeverExecuted() {
		long count =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.peek(i -> {
					throw new RuntimeException("never runs?");
				})
				.count();

		Assertions.assertEquals(9, count);
	}

	@Test @Order(2)
	public void peekNeverExecuted2() {
		long count =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.map(val -> val + 1)
				.peek(i -> {
					throw new RuntimeException("never runs?");
				})
				.count();

		Assertions.assertEquals(9, count);
	}

	@Test @Order(3)
	public void peekSuddenlyExecuted() {
		Assertions.assertThrows(
			RuntimeException.class,
			() -> {
				Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
					.map(val -> val + 1)
					.filter(val -> val > 3)
					.peek(i -> {
						throw new RuntimeException("never runs?");
					})
					.count();
			}
		);
	}

	@Test
	public void pleaseBeCareful() {
		// that works, although please avoid
		{
			List<Integer> result = new ArrayList<>();
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.filter(val -> val > 3)
				.forEach(result::add);
		}

		// that will induce chaos and destruction
		{
			List<Integer> result = new ArrayList<>();
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.parallel()
				.filter(val -> val > 3)
				.forEach(result::add);
		}

		// that works, although it's really bad practice
		{
			List<Integer> result = new ArrayList<>();
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.parallel()
				.filter(val -> val > 3)
				.forEachOrdered(result::add);
		}

		// that is pro level stuff, usually you can do better with appropriate collectors
		{
			Queue<Integer> result = new ConcurrentLinkedQueue<>();
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.parallel()
				.filter(val -> val > 3)
				.forEach(result::add);
		}
	}
}
