package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

public class Optionals {
	@Test
	public void main() {
		// optional creation
		Optional<Object> value1 = Optional.empty();
		Optional<Integer> value2 = Optional.of(1);
		Optional<Integer> value3 = Optional.<Integer>ofNullable(null);

		assertAll(
			() -> assertTrue(value1.isEmpty()),
			() -> assertTrue(value2.isPresent()),
			() -> assertTrue(value3.isEmpty())
		);
	}

	@Test
	public void ifPresent() {
		Optional<Integer> opt = Optional.of(1);

		AtomicInteger didRun = new AtomicInteger(0);
		opt.ifPresent(
			value -> didRun.incrementAndGet()
		);

		assertTrue(didRun.get() > 0);
	}

	@Test
	public void get() {
		Optional<Integer> opt = Optional.empty();
		assertThrows(NoSuchElementException.class, () -> opt.get());
	}

	@Test
	public void ifPresentOrElse() {
		AtomicInteger check = new AtomicInteger(0);

		Optional.empty().ifPresentOrElse(
			val -> {
				throw new RuntimeException("should not be called");
			},
			() -> {
				// should be called
				check.incrementAndGet();
			}
		);

		assertTrue(check.get() > 0);
	}

	@Test
	public void fallbackToValue() {
		Optional<Integer> empty = Optional.<Integer>empty();
		Optional<Integer> nonEmpty = Optional.of(10);

		assertEquals(
			-1,
			empty.orElse(-1)
		);
		assertEquals(
			10,
			nonEmpty.orElse(-1)
		);
		assertEquals(
			10,
			empty.or(() -> nonEmpty).orElse(-1)
		);
		assertEquals(
			10,
			nonEmpty.orElseGet(Optionals::emulateLongComputation)
		);
	}

	private static int emulateLongComputation() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}

		return 1000;
	}
}
