package com.luxoft.lmd.forkjoin;

import java.util.concurrent.RecursiveTask;

public class SumTask extends RecursiveTask<Long> {
	private final int[] data;
	private final int high;
	private final int low;

	static final int SEQUENTIAL_THRESHOLD = 100_000;

	public SumTask(int[] data, int low, int high) {
		this.data = data;
		this.high = high;
		this.low = low;
	}

	@Override protected Long compute() {
		if (taskSmallEnough())
			return sumRange(data, low, high);

		int mid = low + (high - low) / 2;
		SumTask left = new SumTask(data, low, mid);
		SumTask right = new SumTask(data, mid, high);
		left.fork();
		long rightResult = right.compute();
		long leftResult = left.join();
		return leftResult + rightResult;
	}

	private boolean taskSmallEnough() {
		return high - low <= SEQUENTIAL_THRESHOLD;
	}

	private static long sumRange(int[] data, int lo, int hi) {
		long sum = 0;
		for (int i = lo; i < hi; i++)
			sum += data[i];
		return sum;
	}
}
