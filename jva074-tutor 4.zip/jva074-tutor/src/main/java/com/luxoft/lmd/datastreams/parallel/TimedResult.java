package com.luxoft.lmd.datastreams.parallel;

import java.time.Duration;

public record TimedResult<V>(V result, Duration duration) {
}
