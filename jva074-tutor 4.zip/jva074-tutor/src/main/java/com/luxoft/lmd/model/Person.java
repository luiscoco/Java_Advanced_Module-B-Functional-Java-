package com.luxoft.lmd.model;

public record Person(String name, Gender gender, int age, int childCount) {
	public enum Gender {
		MALE, FEMALE
	}
}
