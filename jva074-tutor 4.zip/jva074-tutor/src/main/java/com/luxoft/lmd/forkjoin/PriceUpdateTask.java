package com.luxoft.lmd.forkjoin;

import java.util.List;
import java.util.concurrent.RecursiveAction;

class PriceUpdateTask extends RecursiveAction {

	private static final long serialVersionUID = 1L;

	private final List<Product> products;
	private final int first;
	private final int last;
	private final double increment;

	public PriceUpdateTask(List<Product> products, int first, int last, double increment) {
		this.products = products;
		this.first = first;
		this.last = last;
		this.increment = increment;
	}

	@Override
	protected void compute() {
		if (isSmallEnough()) {
			conquer();
		} else {
			divide();
		}
	}

	private void divide() {
		int middle = (first + last) / 2;
		PriceUpdateTask l = new PriceUpdateTask(
			products, first, middle + 1, increment);
		PriceUpdateTask r = new PriceUpdateTask(
			products, middle + 1, last, increment);
		invokeAll(l, r);
	}

	private boolean isSmallEnough() {
		return last - first < 100;
	}

	private void conquer() {
		for (int i = first; i < last; i++) {
			Product product = products.get(i);
			product.setPrice(
				product.getPrice() +
					(int) (product.getPrice() * increment));
		}
	}

}
