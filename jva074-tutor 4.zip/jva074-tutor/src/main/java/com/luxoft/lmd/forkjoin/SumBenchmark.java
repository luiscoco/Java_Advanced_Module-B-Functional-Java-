package com.luxoft.lmd.forkjoin;

import com.luxoft.lmd.datastreams.parallel.Timing;
import net.datafaker.Faker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.IntStream;

public class SumBenchmark {
	public static final Logger logger = LoggerFactory.getLogger(SumBenchmark.class);

	public static void main(String[] args) {
		Faker faker = new Faker();
		int dataSize = 1_000_000;

		int[] data =
			IntStream.generate(() -> faker.random().nextInt(0, 200))
				.limit(dataSize)
				.toArray();

		int testCount = 5;

		Timing.benchmark("sumSeq", testCount, () -> sumSequential(data));
		Timing.benchmark("sumStreams", testCount, () -> sumUsingStream(data, false));
		Timing.benchmark("sumStreamsParallel", testCount, () -> sumUsingStream(data, true));
		Timing.benchmark("sumForkJoin", testCount, () -> sumUsingForkJoin(data));
	}

	public static long sumSequential(int[] data) {
		long sum = 0;
		for (int i = 0; i < data.length; i++) {
			sum += data[i];
		}
		return sum;
	}

	public static long sumUsingStream(int data[], boolean parallel) {
		IntStream stream = Arrays.stream(data);
		if (parallel)
			stream = stream.parallel();
		return stream.sum();
	}

	public static long sumUsingForkJoin(int[] data) {
		ForkJoinPool pool = ForkJoinPool.commonPool();
		Long result = pool.invoke(new SumTask(data, 0, data.length));
		return result;
	}
}
