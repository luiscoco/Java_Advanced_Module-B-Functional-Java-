package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.function.UnaryOperator;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;

public class FunctionComposition {
	UnaryOperator<Integer> f1 = a -> a + 1;
	UnaryOperator<Integer> f2 = a -> a * 2;
	List<Integer> input = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9);

	@Test
	public void f1Thenf2() {
		List<Integer> result1 =
			input.stream()
				.map(f1)
				.map(f2)
				.toList();

		List<Integer> result2 =
			input.stream()
				.map(f1.andThen(f2))
				.toList();

		assertAll(
			() -> assertIterableEquals(List.of(4, 6, 8, 10, 12, 14, 16, 18, 20), result1),
			() -> assertIterableEquals(result1, result2)
		);
	}

	@Test
	public void f1Composef2() {
		List<Integer> result1 =
			input.stream()
				.map(f2)
				.map(f1)
				.toList();

		List<Integer> result2 =
			input.stream()
				.map(f1.compose(f2))
				.toList();

		assertAll(
			() -> assertIterableEquals(List.of(3, 5, 7, 9, 11, 13, 15, 17, 19), result1),
			() -> assertIterableEquals(result1, result2)
		);
	}
}
